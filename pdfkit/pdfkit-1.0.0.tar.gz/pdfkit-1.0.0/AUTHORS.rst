=====================
Python-PDFKit authors
=====================

* `Stanislav Golovanov <https://github.com/JazzCore>`_


Contributors
------------

* `Tomscytale <https://github.com/tomscytale>`_
* `Matheus Marchini <https://github.com/mmarchini>`_
* `Rory McCann <https://github.com/rory>`_
* `Matheus Marchini <https://github.com/mmarchini>`_
* `signalkraft <https://github.com/signalkraft>`_
* `Pietro Delsante <https://github.com/pdelsante>`_
* `Hung Le <https://github.com/lexhung>`_
* `Zachary Kazanski <https://github.com/Kazanz>`_
* `Fasih Ahmad Fakhri <https://github.com/fasih>`_
* `Alan Hamlett <https://github.com/alanhamlett>`_

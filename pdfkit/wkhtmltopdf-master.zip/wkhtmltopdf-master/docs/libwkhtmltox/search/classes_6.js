var searchData=
[
  ['size_95',['Size',['../structwkhtmltopdf_1_1settings_1_1Size.html',1,'wkhtmltopdf::settings']]]
];

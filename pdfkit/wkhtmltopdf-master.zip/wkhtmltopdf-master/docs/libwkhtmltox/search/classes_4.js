var searchData=
[
  ['pdfglobal_80',['PdfGlobal',['../structwkhtmltopdf_1_1settings_1_1PdfGlobal.html',1,'wkhtmltopdf::settings']]],
  ['pdfobject_81',['PdfObject',['../structwkhtmltopdf_1_1settings_1_1PdfObject.html',1,'wkhtmltopdf::settings']]]
];

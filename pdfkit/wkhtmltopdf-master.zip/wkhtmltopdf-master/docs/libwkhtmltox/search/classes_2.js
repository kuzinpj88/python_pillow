var searchData=
[
  ['imageglobal_78',['ImageGlobal',['../structwkhtmltopdf_1_1settings_1_1ImageGlobal.html',1,'wkhtmltopdf::settings']]]
];

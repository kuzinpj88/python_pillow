var searchData=
[
  ['cropsettings_76',['CropSettings',['../structwkhtmltopdf_1_1settings_1_1CropSettings.html',1,'wkhtmltopdf::settings']]]
];

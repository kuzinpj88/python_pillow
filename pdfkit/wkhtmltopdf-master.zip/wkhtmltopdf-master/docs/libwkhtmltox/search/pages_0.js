var searchData=
[
  ['setting_153',['Setting',['../pagesettings.html',1,'']]]
];

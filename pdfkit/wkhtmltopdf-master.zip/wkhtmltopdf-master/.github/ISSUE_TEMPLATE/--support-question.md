---
name: "⛔ Support Question"
about: See https://wkhtmltopdf.org/support.html for questions.

---

We use GitHub issues only to discuss about wkhtmltopdf bugs and new features. For
this kind of questions about using wkhtmltopdf, please use
any of the support alternatives shown in https://wkhtmltopdf.org/support.html or 
post an issue on https://stackoverflow.com/.

Thanks!

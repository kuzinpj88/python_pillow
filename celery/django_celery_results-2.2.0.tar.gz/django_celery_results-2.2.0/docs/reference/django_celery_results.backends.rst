=====================================================
 ``django_celery_results.backends``
=====================================================

.. contents::
    :local:
.. currentmodule:: django_celery_results.backends

.. automodule:: django_celery_results.backends
    :members:
    :undoc-members:

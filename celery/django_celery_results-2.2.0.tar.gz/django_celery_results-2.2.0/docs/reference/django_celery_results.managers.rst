=====================================================
 ``django_celery_results.managers``
=====================================================

.. contents::
    :local:
.. currentmodule:: django_celery_results.managers

.. automodule:: django_celery_results.managers
    :members:
    :undoc-members:

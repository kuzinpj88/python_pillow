=====================================================
 ``django_celery_results.backends.database``
=====================================================

.. contents::
    :local:
.. currentmodule:: django_celery_results.backends.database

.. automodule:: django_celery_results.backends.database
    :members:
    :undoc-members:

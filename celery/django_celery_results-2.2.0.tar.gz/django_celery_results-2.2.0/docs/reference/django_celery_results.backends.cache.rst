=====================================================
 ``django_celery_results.backends.cache``
=====================================================

.. contents::
    :local:
.. currentmodule:: django_celery_results.backends.cache

.. automodule:: django_celery_results.backends.cache
    :members:
    :undoc-members:

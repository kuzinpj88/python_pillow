.. _apiref:

===============
 API Reference
===============

:Release: |version|
:Date: |today|

.. toctree::
    :maxdepth: 1

    django_celery_results.backends
    django_celery_results.backends.database
    django_celery_results.backends.cache
    django_celery_results.models
    django_celery_results.managers
    django_celery_results.utils

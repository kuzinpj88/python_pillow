=====================================================
 ``django_celery_results.models``
=====================================================

.. contents::
    :local:
.. currentmodule:: django_celery_results.models

.. automodule:: django_celery_results.models
    :members:
    :undoc-members:

=====================================================
 ``django_celery_results.utils``
=====================================================

.. contents::
    :local:
.. currentmodule:: django_celery_results.utils

.. automodule:: django_celery_results.utils
    :members:
    :undoc-members:

=======================================================================
 django-celery-results - Celery Result Backends for Django
=======================================================================

.. include:: includes/introduction.txt

Contents
========

.. toctree::
    :maxdepth: 1

    copyright

.. toctree::
    :maxdepth: 2

    reference/index

.. toctree::
    :maxdepth: 1

    changelog
    glossary

Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`


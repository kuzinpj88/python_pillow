===========================================================
 ``celery.bin.amqp``
===========================================================

.. contents::
    :local:
.. currentmodule:: celery.bin.amqp

.. automodule:: celery.bin.amqp
    :members:
    :undoc-members:

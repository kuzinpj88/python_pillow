================================================
 ``celery.backends.cosmosdbsql``
================================================

.. contents::
    :local:
.. currentmodule:: celery.backends.cosmosdbsql

.. automodule:: celery.backends.cosmosdbsql
    :members:
    :undoc-members:

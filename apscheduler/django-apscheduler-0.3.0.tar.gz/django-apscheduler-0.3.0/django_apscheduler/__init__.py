default_app_config = 'django_apscheduler.apps.DjangoApschedulerConfig'
